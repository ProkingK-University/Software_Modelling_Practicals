#include "Observer.h"

Observer::Observer(std::string name)
{
    this->name = name;
}