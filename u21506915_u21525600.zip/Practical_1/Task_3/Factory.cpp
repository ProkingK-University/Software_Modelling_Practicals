#include "Factory.h"

Factory::~Factory()
{
    
}